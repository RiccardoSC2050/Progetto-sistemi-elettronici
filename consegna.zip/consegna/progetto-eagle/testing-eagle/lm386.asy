Version 4
SymbolType BLOCK
RECTANGLE Normal -64 -72 64 72
WINDOW 0 0 -72 Bottom 2
SYMATTR Prefix X
SYMATTR Value lm386
SYMATTR ModelFile LM386_Dilatush.lib
WINDOW 3 0 72 Top 2
PIN -64 -48 LEFT 8
PINATTR PinName inn
PINATTR SpiceOrder 1
PIN -64 -16 LEFT 8
PINATTR PinName inp
PINATTR SpiceOrder 2
PIN -64 16 LEFT 8
PINATTR PinName byp
PINATTR SpiceOrder 3
PIN -64 48 LEFT 8
PINATTR PinName g1
PINATTR SpiceOrder 4
PIN 64 -48 RIGHT 8
PINATTR PinName g8
PINATTR SpiceOrder 5
PIN 64 -16 RIGHT 8
PINATTR PinName out
PINATTR SpiceOrder 6
PIN 64 16 RIGHT 8
PINATTR PinName vs
PINATTR SpiceOrder 7
PIN 64 48 RIGHT 8
PINATTR PinName gnd
PINATTR SpiceOrder 8
